class Round:
    def __init__(self, dice):
        self.dice = sorted(dice)
        self.all_dice_sum = sum(self.dice)
        self.points = [0] * 13
        self.category = set()

        if self.isFull():
            self.category.add(12)
            self.points[12] = 40
        if self.longStraight():
            self.category.add(11)
            self.points[11] = 35
        if self.shortStraight():
            self.category.add(10)
            self.points[10] = 25
        if self.isFive():
            self.category.add(9)
            self.points[9] = 50
        if self.isFour():
            self.category.add(8)
            self.points[8] = self.all_dice_sum
        if self.isThree():
            self.category.add(7)
            self.points[7] = self.all_dice_sum

        self.category.add(6)
        self.points[6] = self.all_dice_sum

        for v in range(1, 7):
            if v in self.dice:
                self.category.add(v - 1)
                self.points[v - 1] = self.dice.count(v) * v

    def isFull(self):
        distinct_dice = set(self.dice)
        return len(distinct_dice) == 2 and (self.dice.count(self.dice[0]) == 3 or self.dice.count(self.dice[0]) == 2)

    def longestSeq(self):
        longest = curr_len = 1
        for i in range(1, len(self.dice)):
            if self.dice[i] == self.dice[i - 1]:
                continue
            elif self.dice[i] - self.dice[i - 1] == 1:
                curr_len += 1
            else:
                longest = max(longest, curr_len)
                curr_len = 1
        return max(longest, curr_len)

    def longStraight(self):
        return self.longestSeq() >= 5

    def shortStraight(self):
        return self.longestSeq() >= 4

    def isFive(self):
        return len(set(self.dice)) == 1

    def isFour(self):
        return (self.dice.count(self.dice[0]) >= 4 or self.dice.count(self.dice[1]) >= 4)

    def isThree(self):
        return (self.dice.count(self.dice[0]) >= 3 or self.dice.count(self.dice[1]) >= 3 or self.dice.count(self.dice[2]) >= 3)

class Yahtzee:
    def __init__(self, input):
        self.best_solution_result = [0, 0]
        self.best_solution = [0] * 13
        self.solve(input)

    def solve(self, input):
        candidate_solution = [0] * 13
        for category in range(12, 8, -1):
            dice = self.filter(category, input)
            if dice:
                min_dice = min(dice, key=lambda x: x.all_dice_sum)
                input.remove(min_dice)
                candidate_solution[category] = min_dice.points[category]

        self.search(8, input, candidate_solution)

    def filter(self, category, input):
        return [d for d in input if category in d.category]

    def total(self, solution):
        six_sum = sum(solution[:6])
        total_points = sum(solution)
        bonus = 35 if six_sum >= 63 else 0
        return [bonus, total_points + bonus]

    def search(self, pos, input, solution):
        if pos == -1:
            solution_result = self.total(solution)
            if self.best_solution_result[1] < solution_result[1]:
                self.best_solution = solution[:]
                self.best_solution_result = solution_result[:]
            return

        candidates = self.filter(pos, input)
        checked = set()
        for round in candidates:
            if round in checked:
                continue
            solution[pos] = round.points[pos]
            input.remove(round)
            self.search(pos - 1, input, solution)
            solution[pos] = 0
            input.append(round)
            checked.add(round)

        if pos >= 7 or not candidates:
            solution[pos] = 0
            self.search(pos - 1, input, solution)

    def get_solution_string(self):
        return ' '.join(map(str, self.get_solution()))

    def get_solution(self):
        return self.best_solution + self.best_solution_result

import sys
input = []
current_line = sys.stdin.read().strip().splitlines()
for line in current_line:
    if line.strip():
        dice = list(map(int, line.strip().split()))
        input.append(dice)
        if len(input) == 13:
            yahtzee = Yahtzee([Round(d) for d in input])
            print(yahtzee.get_solution_string())
            input.clear()