from collections import defaultdict

class Card:
    # Mapping card values and suits
    map = {str(c): c for c in range(2, 10)}
    map.update({'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14})
    suit_map = {'C': 1, 'D': 2, 'H': 3, 'S': 4}

    def __init__(self, value, suit):
        self.value = Card.map[value]
        self.suit = Card.suit_map[suit]

class Hand:
    def __init__(self, hand):
        self.hand = sorted(hand, key=lambda x: x.value)
        self.category = 0
        self.rank = []
        self.evaluate_hand()

    def evaluate_hand(self):
        if self.is_straight_flush():
            self.category = 9
            self.rank = [self.hand[-1].value]
        elif self.is_four_of_a_kind():
            self.category = 8
        elif self.is_full_house():
            self.category = 7
        elif self.is_flush():
            self.category = 6
            self.rank = [card.value for card in reversed(self.hand)]
        elif self.is_straight():
            self.category = 5
            self.rank = [self.hand[-1].value]
        elif self.is_three_of_a_kind():
            self.category = 4
        elif self.is_two_pairs():
            self.category = 3
        elif self.is_pair():
            self.category = 2
        else:
            self.category = 1
            self.rank = [card.value for card in reversed(self.hand)]

    def is_straight_flush(self):
        return self.is_flush() and self.is_straight()

    def is_four_of_a_kind(self):
        count = self.groups()
        if 4 in count.values():
            four_card = max(count, key=lambda k: count[k] == 4)
            kicker = min(count, key=lambda k: count[k] == 1)
            self.rank = [four_card, kicker]
            return True
        return False

    def is_full_house(self):
        count = self.groups()
        if 3 in count.values() and 2 in count.values():
            three_card = max(count, key=lambda k: count[k] == 3)
            pair_card = min(count, key=lambda k: count[k] == 2)
            self.rank = [three_card, pair_card]
            return True
        return False

    def is_flush(self):
        return all(card.suit == self.hand[0].suit for card in self.hand)

    def is_straight(self):
        values = [card.value for card in self.hand]
        return all(values[i] == values[i - 1] + 1 for i in range(1, len(values)))

    def is_three_of_a_kind(self):
        count = self.groups()
        if 3 in count.values():
            three_card = max(count, key=lambda k: count[k] == 3)
            kickers = sorted([k for k in count if count[k] != 3], reverse=True)
            self.rank = [three_card] + kickers
            return True
        return False

    def is_two_pairs(self):
        count = self.groups()
        pairs = [k for k, v in count.items() if v == 2]
        if len(pairs) == 2:
            pairs.sort(reverse=True)
            kicker = [k for k in count if count[k] == 1][0]
            self.rank = pairs + [kicker]
            return True
        return False

    def is_pair(self):
        count = self.groups()
        if 2 in count.values():
            pair_card = max(count, key=lambda k: count[k] == 2)
            kickers = sorted([k for k in count if count[k] != 2], reverse=True)
            self.rank = [pair_card] + kickers
            return True
        return False

    def groups(self):
        count = defaultdict(int)
        for card in self.hand:
            count[card.value] += 1
        return count

def compare(black, white):
    if black.category != white.category:
        return black.category - white.category
    else:
        # Compare ranks as a tuple for easy handling of tiebreakers
        return (black.rank > white.rank) - (black.rank < white.rank)

def get_hand(h):
    return Hand([Card(x[0], x[1]) for x in h])

def main():
    try:
        while True:
            current_line = input().split()
            black = get_hand(current_line[:5])
            white = get_hand(current_line[5:])
            cmp = compare(black, white)
            if cmp == 0:
                print("Tie.")
            else:
                print("Black wins." if cmp > 0 else "White wins.")
    except EOFError:
        pass

if __name__ == "__main__":
    main()