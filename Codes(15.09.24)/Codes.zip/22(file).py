import sys

def fit(fragments, candidate):
    temp = fragments.copy()
    for i in range(1, len(candidate)):
        if not temp:
            break
        prefix = candidate[:i]
        suffix = candidate[i:]
        temp = [x for x in temp if x.lower() != prefix.lower()]
        temp = [x for x in temp if x.lower() != suffix.lower()]
    return not temp

def restore(fragments):
    fragments.sort(key=len)
    largest = fragments[-1]
    smallest = [x for x in fragments if len(x) == len(fragments[0])]
    
    for small in smallest:
        if fit(fragments, largest + small):
            return largest + small
        elif fit(fragments, small + largest):
            return small + largest
    return "Impossible"

n = int(sys.stdin.readline().strip())
sys.stdin.readline()  
results = []
for _ in range(n):
    fragments = []
    while True:
        try:
            s = sys.stdin.readline().strip()
            if not s:
                break
            fragments.append(s)
        except EOFError:
            break
    results.append(restore(fragments))
    if _ < n - 1:
        results.append("")  
print("\n".join(results))