# PC/UVa IDs: 110105/10267

def initialize_image(m, n):
    """Create a new image with all pixels colored white (O)."""
    return [['O' for _ in range(m)] for _ in range(n)]

def clear_image(image):
    """Clear the image by setting all pixels to white (O)."""
    for row in image:
        for j in range(len(row)):
            row[j] = 'O'

def color_pixel(image, x, y, c):
    """Color the pixel (X, Y) in color (C)."""
    image[y - 1][x - 1] = c

def draw_vertical(image, x, y1, y2, c):
    """Draw a vertical segment of color (C) in column X between rows Y1 and Y2."""
    for y in range(y1 - 1, y2):
        image[y][x - 1] = c

def draw_horizontal(image, x1, x2, y, c):
    """Draw a horizontal segment of color (C) in row Y between columns X1 and X2."""
    for x in range(x1 - 1, x2):
        image[y - 1][x] = c

def draw_rectangle(image, x1, y1, x2, y2, c):
    """Draw a filled rectangle of color C."""
    for y in range(y1 - 1, y2):
        for x in range(x1 - 1, x2):
            image[y][x] = c

def fill_region(image, x, y, new_color):
    """Fill the region R with color C."""
    original_color = image[y - 1][x - 1]
    if original_color == new_color:
        return
    stack = [(x - 1, y - 1)]
    while stack:
        cx, cy = stack.pop()
        if 0 <= cx < len(image[0]) and 0 <= cy < len(image):
            if image[cy][cx] == original_color:
                image[cy][cx] = new_color
                stack.append((cx + 1, cy))
                stack.append((cx - 1, cy))
                stack.append((cx, cy + 1))
                stack.append((cx, cy - 1))

def save_image(image, name):
    """Print the filename and contents of the current image."""
    print(name)
    for row in image:
        print(''.join(row))

def main():
    import sys

    image = []
    m, n = 0, 0
    
    for line in sys.stdin:
        command = line.strip().split()
        if not command:
            continue
        
        cmd = command[0]

        if cmd == 'I':
            m, n = int(command[1]), int(command[2])
            image = initialize_image(m, n)
        elif cmd == 'C':
            clear_image(image)
        elif cmd == 'L':
            x, y, c = int(command[1]), int(command[2]), command[3]
            color_pixel(image, x, y, c)
        elif cmd == 'V':
            x, y1, y2, c = int(command[1]), int(command[2]), int(command[3]), command[4]
            draw_vertical(image, x, y1, y2, c)
        elif cmd == 'H':
            x1, x2, y, c = int(command[1]), int(command[2]), int(command[3]), command[4]
            draw_horizontal(image, x1, x2, y, c)
        elif cmd == 'K':
            x1, y1, x2, y2, c = int(command[1]), int(command[2]), int(command[3]), int(command[4]), command[5]
            draw_rectangle(image, x1, y1, x2, y2, c)
        elif cmd == 'F':
            x, y, c = int(command[1]), int(command[2]), command[3]
            fill_region(image, x, y, c)
        elif cmd == 'S':
            name = command[1]
            save_image(image, name)
        elif cmd == 'X':
            break

if __name__ == "__main__":
    main()
