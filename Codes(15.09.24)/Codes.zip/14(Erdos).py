import re
from collections import deque, defaultdict

ERDOS = "Erdos, P."

def add(graph, names):
    for curr_name in names:
        if curr_name not in graph:
            graph[curr_name] = set()
        for name in names:
            if curr_name != name:
                graph[curr_name].add(name)

def get_names(input_str):
    name_pattern = re.compile(r'[\w^.,]+,\s*(\w\.)+\s*[,:]')
    return [input_str[m.start():m.end()-1].strip() for m in name_pattern.finditer(input_str)]

def get_answer(graph):
    q = deque([ERDOS])
    visited = set()
    result = {ERDOS: 0}

    while q:
        current = q.popleft()
        depth = result[current]
        for neighbor in graph.get(current, []):
            if neighbor not in visited:
                visited.add(neighbor)
                q.append(neighbor)
                result[neighbor] = depth + 1

    return result

def main():
    import sys
    input = sys.stdin.read
    data = input().strip().splitlines()
    
    n = int(data[0])
    index = 1

    results = []

    for scenario in range(1, n + 1):
        p, q = map(int, data[index].split())
        index += 1
        
        graph = defaultdict(set)
        for _ in range(p):
            paper = data[index].strip()
            names = get_names(paper)
            add(graph, names)
            index += 1

        erdos_numbers = get_answer(graph)
        
        results.append(f"Scenario {scenario}")
        for _ in range(q):
            name = data[index].strip()
            erdos_number = erdos_numbers.get(name, "infinity")
            results.append(f"{name} {erdos_number}")
            index += 1

    print("\n".join(results))

if __name__ == "__main__":
    main()