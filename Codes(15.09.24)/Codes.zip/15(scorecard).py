class Team:
    def __init__(self, num):
        self.num = num
        self.total_time = 0
        self.solved = set()
        self.penalties = [0] * 10

    def get_total_time(self):
        return self.total_time + sum(self.penalties[i] for i in self.solved)

    def update(self, problem, time, verdict):
        if verdict == "C":
            if problem not in self.solved:
                self.solved.add(problem)
                self.total_time += time
        elif verdict == "I":
            if problem not in self.solved:
                self.penalties[problem] += 20

    def __str__(self):
        return f"{self.num} {len(self.solved)} {self.get_total_time()}"

def main():
    import sys
    input = sys.stdin.read
    data = input().strip().splitlines()
    
    cases = int(data[0])
    index = 1

    for _ in range(cases):
        participants = {}
        
        while index < len(data) and data[index].strip() != "":
            parts = data[index].strip().split()
            num = int(parts[0])
            problem = int(parts[1])
            time = int(parts[2])
            verdict = parts[3]

            if num not in participants:
                participants[num] = Team(num)
            participants[num].update(problem, time, verdict)
            index += 1
        
        sorted_teams = sorted(participants.values(), key=lambda t: (-len(t.solved), t.get_total_time(), t.num))
        
        for team in sorted_teams:
            print(team)
        
        if index < len(data):
            print()
        
        index += 1  # Move past the blank line

if __name__ == "__main__":
    main()
