# PC/UVa IDs: 110204/843, 

def decrypt_lines(n, dictionary, encrypted_lines):
    def backtrack(index, mapping, reverse_mapping):
        if index == len(encrypted_words):
            return True

        word = encrypted_words[index]
        word_length = len(word)

        for dict_word in dictionary:
            if len(dict_word) != word_length:
                continue
            
            # Create potential mapping
            temp_mapping = {}
            temp_reverse_mapping = {}
            for c, d in zip(word, dict_word):
                if c in mapping:
                    if mapping[c] != d:
                        break
                if d in reverse_mapping:
                    if reverse_mapping[d] != c:
                        break
                temp_mapping[c] = d
                temp_reverse_mapping[d] = c
            else:
                # Update the mappings
                mapping.update(temp_mapping)
                reverse_mapping.update(temp_reverse_mapping)

                # Recurse to the next word
                if backtrack(index + 1, mapping, reverse_mapping):
                    return True

                # Backtrack
                for c in temp_mapping:
                    del mapping[c]
                for d in temp_reverse_mapping:
                    del reverse_mapping[d]

        return False

    results = []
    for line in encrypted_lines:
        encrypted_words = line.split()
        mapping = {}
        reverse_mapping = {}
        if backtrack(0, mapping, reverse_mapping):
            # Construct the decrypted line
            decrypted_line = []
            for word in encrypted_words:
                decrypted_word = ''.join(mapping[c] for c in word)
                decrypted_line.append(decrypted_word)
            results.append(' '.join(decrypted_line))
        else:
            # No valid mapping found
            results.append('*' * sum(len(word) for word in encrypted_words) + ' ' * (len(encrypted_words) - 1))

    return results

# Main function to read input and produce output
def main():
    import sys
    input = sys.stdin.read
    data = input().splitlines()
    
    n = int(data[0])  # Number of words in the dictionary
    dictionary = data[1:n + 1]  # Dictionary words
    encrypted_lines = data[n + 1:]  # Encrypted input lines
    
    results = decrypt_lines(n, dictionary, encrypted_lines)
    
    for result in results:
        print(result)

if __name__ == "__main__":
    main()